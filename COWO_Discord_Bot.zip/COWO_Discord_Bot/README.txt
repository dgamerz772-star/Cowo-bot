COWO Discord Bot
================

Commands use the prefix c!

c!hunt
c!balance
c!daily
c!inventory
c!shop
c!buy cookie
c!battle @user
c!leaderboard
c!profile
c!helpme
c!addcoins @user 500  (admin only)

PHONE / TERMUX SETUP
1. Install Python in your Termux environment.
2. Put these files in one folder.
3. Rename .env.example to .env
4. Open .env and put your bot token after DISCORD_TOKEN= .
5. Run:
   pip install -r requirements.txt
   python bot.py

IMPORTANT:
- Never share your bot token with anyone.
- In Discord Developer Portal, create the bot and invite it with bot + applications.commands scopes.
- Give only the permissions your bot needs.
